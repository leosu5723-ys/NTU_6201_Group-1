# PE6201 A2 team review pack R2

This release replaces the earlier incomplete worksheet and partial code ZIP. It is not a submission package or frozen live-run release.

1. Everyone: extract PHASE_A_CASE_AUTHORING_R2 first. Read its START_HERE.md and write your assigned case contracts.
2. Only after returning those independent contracts: extract PHASE_B_CODE_REVIEW_R2 for code/strand review and offline reproduction. It contains answer keys and Agent evidence.
3. Integration owner: read R2_CORRECTION_NOTICE.md before merging member responses. Preserve real authorship. Do not relabel another member's work.
4. No API key is required now. Wait for the common frozen Git commit and final live instructions.

VERIFICATION.json records actual checks from an independently extracted Phase B package. The archive manifests bind these files, not an experimental Git freeze.
