# Phase B: code and strand review (R2)

Open only after returning your independently written Phase A case contracts. This package includes answer keys and Agent evidence.
Read review/TEAM_ACTION_PACK.md and review/CODE_WALKTHROUGH.md, then inspect the files under your name. Return your strand explanation, questions/corrections and name/date.

## Offline reproduction

This is a source snapshot without .git history, not a frozen live-run release. Do not run git checkout here and do not add an API key.
Tested on macOS with Python 3.11. Python and Git are needed for the full test suite; Python dependencies are standard-library only. The tool layer imports fcntl, so native Windows is not supported; use a Linux/WSL environment or ask the integration owner for help. Other platforms were not verified in this release.
In a terminal, enter this extracted folder and run:

```bash
python3 A2_reference_data/check_my_data.py
python3 -m unittest discover -s tests -q
python3 run_eval.py
python3 run_eval.py --guardrails
```

These checks are free. Generated outputs may change during reproduction; this snapshot does not promise a clean Git state. The guide's git checkout / clean-commit checks apply only to the later frozen repository release.
No member's live battery, case signature or final submission approval is supplied by this package. Model IDs and prices must be revalidated before the final freeze/run instructions are issued.
