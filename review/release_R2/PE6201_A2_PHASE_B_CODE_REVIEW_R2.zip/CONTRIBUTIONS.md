# Contribution Record

This file records completed, reviewable work. Intended responsibilities are not marked complete until evidence exists.

## Collaboration method

The repository is maintained as one integrated system to avoid incompatible modules and experimental drift. AI assistance has been used substantially for implementation drafts, test generation, debugging, documentation and mechanical verification. Team members remain responsible for understanding the submitted system, reviewing the evaluation ground truth, running the assigned live measurements, interpreting the results and approving the final submission.

## Responsibility and evidence

| Member | Responsibility | Required evidence before final submission | Status |
|---|---|---|---|
| Meng Sijia | Evaluation harness review; Gemini 2.5 Flash Lite v2 battery | Review notes or approved cases; complete raw v2 result file | Pending team action |
| SHI SHUYI | Integrated loop and tool-layer review; Qwen3 30B A3B Instruct v2 battery | Design review decisions; complete raw Qwen result file | Integrated build coordination in progress |
| Su Yang | Cost model review; Claude Haiku 4.5 v2 battery | Checked assumptions and calculations; complete raw Claude result file | Pending team action |
| Isha Kirti Ghia | Tool and dependency review; Llama 4 Maverick v2 battery | Review notes or approved cases; complete raw Llama result file | Pending team action |
| Sun Hanyu | Evaluation and scripted-run review; DeepSeek V3.2 v2 battery | Review notes or approved cases; complete raw DeepSeek result file | Pending team action |
| Zhang Jiayang | Descriptor v1 to v2 review; Gemini 2.5 Flash Lite v1 battery | Confirmed prompt delta; complete raw v1 result file | Pending team action |
| Everyone | Evaluation-contract authorship/substantive revision, case review, final report review and recorded demonstration | Case-specific authored contracts and revision records under the assigned member; final approval; individual video segment | Pending team action |

## Integrated build evidence

Current local evidence includes:

- A 40-case fixture set and answer key
- A 60-trial scripted harness
- A standard-library test suite covering the agent, tools, data, guardrails, experiments, live-run controls and privacy
- Ten guardrail cases
- Sequential and parallel comparison
- Two deterministic failure reproductions
- A dry-run-only live battery runner

Counts and statuses must be refreshed from the final clean commit. This file must not be used to claim a member completed work that has no corresponding review, run file, commit, approval or presentation evidence.
