# Phase A: independent case authoring (R2)

Read review/TEAM_ACTION_PACK.md, then the official Problem A Appendix A in official_sources/PE6201_A2_Applied_AI_System.pdf (printed pages 24-25).
Find your name in review/CASE_WORKSHEETS.md and make a personal copy of your section. The full source worksheet has 40 cases, allocated 7/7/7/7/7/5.
Use review/case_review_assignments.md as the allocation authority. Write your final decision contracts, boundary rationale, fixed checks, evidence and must_record requirements. Return your completed section and proposed corrections to SHI SHUYI. Do not merely sign off the draft.
Do not open the Phase B code package or project answer key until your independent contracts have been returned. You do not need Python, Git or an API key for Phase A.
The guide covers later stages too: links to code and result files intentionally refer to Phase B, not missing Phase A attachments. The official brief contains instructor worked examples; do not claim those as your original work.
Do not overwrite existing responses from an earlier version: transfer by exact case ID and preserve the real author/reviewer.
